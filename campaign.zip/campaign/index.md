# Support USDTz 🇹🇷🚀

**USDTz** is a decentralized USD-pegged token built on TRON (TRC20) for fairness, transparency and accessibility.

💡 Help us launch a trusted, open USD value token for the TRON ecosystem.

📌 Website: [https://usdtz.vercel.app](https://usdtz.vercel.app)  
📌 Donate TRX to: `TDhqMjTnDAUxYraTVLLie9Qd8NDGY91idq`
