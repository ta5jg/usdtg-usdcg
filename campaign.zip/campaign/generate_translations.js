const fs = require('fs');
const path = require('path');

// Kaynak dosya
const sourceFile = path.join(__dirname, 'message_en.md');
const content = fs.readFileSync(sourceFile, 'utf8');

// Hedef diller ve dosya adları
const translations = {
  tr: 'Türkçe destek mesajı - (Yapay çeviri)',
  fr: 'Message de soutien en français - (Traduction fictive)',
  de: 'Unterstützungsnachricht auf Deutsch - (Platzhalterübersetzung)',
  es: 'Mensaje de apoyo en español - (Traducción simulada)',
  ru: 'Сообщение поддержки на русском - (Фиктивный перевод)',
  ar: 'رسالة الدعم باللغة العربية - (ترجمة وهمية)',
  hi: 'हिंदी समर्थन संदेश - (काल्पनिक अनुवाद)',
  id: 'Pesan dukungan dalam Bahasa Indonesia - (Terjemahan buatan)',
  zh: '简体中文支持消息 - （模拟翻译）',
  pt: 'Mensagem de apoio em português - (Tradução fictícia)',
  vi: 'Tin nhắn ủng hộ bằng tiếng Việt - (Bản dịch giả)',
  ja: '日本語の支援メッセージ - (仮の翻訳)',
  ko: '한국어 지원 메시지 - (임시 번역)',
  fa: 'پیام پشتیبانی به زبان فارسی - (ترجمه فرضی)',
  it: 'Messaggio di supporto in italiano - (Traduzione simulata)',
  pl: 'Wiadomość wsparcia po polsku - (Tłumaczenie fikcyjne)',
  nl: 'Steunbericht in het Nederlands - (Fictieve vertaling)',
  el: 'Μήνυμα υποστήριξης στα ελληνικά - (Πλασματική μετάφραση)',
  sv: 'Stödmeddelande på svenska - (Fiktiv översättning)',
  no: 'Støttemelding på norsk - (Simulert oversettelse)',
  fi: 'Tukiviesti suomeksi - (Simuloitu käännös)',
  he: 'הודעת תמיכה בעברית - (תרגום מדומה)',
  th: 'ข้อความสนับสนุนภาษาไทย - (การแปลสมมุติ)',
  ur: 'اردو میں سپورٹ پیغام - (خیالی ترجمہ)'
};

// Her dil için dosya oluştur
for (const [lang, header] of Object.entries(translations)) {
  const fileName = `message_${lang}.md`;
  const translated = `${header}\n\n${content}`;
  fs.writeFileSync(path.join(__dirname, fileName), translated);
  console.log(`✅ ${fileName} oluşturuldu.`);
}