# The USDTz Protocol: A Tron-Based Stable Asset

USDTz is a TRC-20 stablecoin pegged 1:1 to USD. It uses a fixed price model with Chainlink oracle fallback, supports a transfer fee system, and includes owner-mint control with a capped max supply of 50 billion tokens.

## Tokenomics
- Max Supply: 50,000,000,000
- Fee: 1% per transfer
- Decimals: 6
- Symbol: USDTz
- Chain: Tron

## Roadmap
- Q2 2025: Token launch + DEX liquidity
- Q3 2025: CoinGecko/CMC listings
- Q4 2025: Wallet integrations

## Risks
- Centralized minting authority initially
- Liquidity-driven price credibility
